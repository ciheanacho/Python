class Item:
    def __init__(self, category, desc, value, quant):
        self.category = category
        self.desc = desc
        self.value = value
        self.quant = quant
    def display(self):
        print("{:<30}{:<18}{:8.2f}{:7d}".format(self.desc, self.category, self.value, self.quant))
class Collection:
    def __init__(self):
        self.items = []
    def addItem(self, category, desc, value, quant):
        item= Item(category,desc,value,quant)
        self.items.append(item)
    def displayAllItems(self):
        I = ' '
        for item in self.items:
            I = I + item + '\n'
        return I
    def displayAllCategories(self):
        print('Categories')
        print('-'*35)
        for category in self.categories:
            print(category)
    def displayAllItemsForCategory(self, category):
        for item in self.items:
            if item in category:
                print('Items for Category:{}'.format(category))
                print("{:<30}{:<18}{:8.2f}{:7d}".format("Description",'Category','Value','Amount'))
                print("{:<30}{:<18}{:8.2f}{:7d}".format(self.desc, self.category, self.value, self.quant))
    def displayItemsOverValue(self, value):

        for item in self.items:
            if item > value:
                print("{:<30}{:<18}{:8.2f}{:7d}".format("Description",'Category','Value','Amount'))
                print("{:<30}{:<18}{:8.2f}{:7d}".format(self.desc, self.category, self.value, self.quant))

    def displayItemFromDescription(self, desc):
        for item in self.items:
            if item.desc == desc:
                print("{:<30}{:<18}{:8.2f}{:7d}".format(self.desc, self.category, self.value, self.quant))
                return
        print('Not Found...')
    def displayCollectionValue(self):
        val = 0
        for item in self.items:
            val = val + item.value
        print('$', val)



