class Coin:
    def __init__(self,type,value,rare,year,grade):
        self.type=type
        self.value=value
        self.rare=rare
        self.year=year
        self.grade=grade
    def __str__(self):
        return self.type+' '+str(self.value)+' '+str(self.rare)+' '+self.year+''+self.grade
    def display(self):
        print(self.type,self.value,self.rare,self.year,self.grade)
    def setRare(self):
        if self.rare == False:
            self.rare = True
            self.value=self.value *1.10

class CoinCollection:
    def __init__(self):
        self.coins= []
    def addcoin(self,type,value,rare,year,grade):
        c = Coin(type,value,rare,year,grade)
        self.coins.append(c)
    def __str__(self):
        s = ' '
        for coin in self.coins:
            s = s + str(coin)+"\n"
        return s

    def printValue(self):
        val=0
        for coin in self.coins:
            val = val + coin.value
        print('$',val)
    def addPreMadeCoin(self,coin):
        self.coins.append(coin)
    def search(self,type):
        for coin in self.coins:
            if coin.type == type:
                print('Found it!')
                return
        print('Not Found...')
# # Coin Collection's API= Application Programming Interface
# c1 = Coin("Roman Neuro AV Aureus Coin", 250.00, True, "58AD", "MS70")
myCoins=CoinCollection()
# myCoins.addcoin()
# # myCoins.addcoin("Roman Neuro AV Aureus Coin", 250.00, True, "58AD", "MS70")
# # c1 = Coin()
# # c2 = Coin()
# print(c1.type)
# print(c1.year)
# # print(c1)
# # c1.display()
# # c1.setRare()
# # c1.display()
# # print(c2)
# # # myCoins=[c1,c2]
# # for coin in myCoins:
# #     print(coin)
# # total=0
# # for coin in myCoins:
# #     total=total+coin.value
# # print('$',total)
type= input('What kind of coin is this?')
value= eval(input('How much is this coin worth?'))
rare1 = input('Is this rare? True or False?')
if rare1 == 'True':
    rare = True
else:
    rare = False
year = input('Enter the year')
grade = input('Enter the grade')
c = Coin(value,rare, year,grade)
myCoins.addcoin(c)

