class Quarter:
    def __init__(self,value,rare,year,grade):
        self.value=value
        self.rare=rare
        self.year=year
        self.grade=grade
    def __str__(self):
        return self.year
    def display(self):
        print(self.value, self.rare, self.year, self.grade)
c1= Quarter(0.25,'False','1925','MS50')
print(c1.year)
print(c1.grade)
print(c1.display())
c1.display()

cat = input("Enter the item's category: ").strip()
desc = input("Enter the item's description: ").strip()
value = eval(input("Enter the item's value: "))
quant = eval(input("Enter the item's quantity: "))